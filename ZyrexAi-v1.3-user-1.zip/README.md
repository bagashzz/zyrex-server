# ZyrexAi (repo modul)
Secret GitHub yang dibutuhkan: `ZY_SERVER` (https://NAMAAPP.NAMAORG.deno.net) dan `ZY_ADMIN_TOKEN`.
- Actions > **Build Modul ZyrexAi** > Run -> artifact `ZyrexAi-module` (zip yang dijual).
- Actions > **Kelola Lisensi** -> tambah/cabut/perpanjang serial pembeli.
Server ada di repo terpisah (Deno Deploy).
