pm uninstall com.zyrex.ai 2>/dev/null; rm -rf /data/adb/zyrexai
