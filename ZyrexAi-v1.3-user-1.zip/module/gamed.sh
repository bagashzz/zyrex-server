#!/system/bin/sh
Z=/data/adb/modules/zyrexai/zyrex.sh; IN=0; OK=0; LT=0; LAST=$(date +%s)
OV=com.zyrex.ai/.OverlayService
revert(){ IN=0; am stopservice -n $OV >/dev/null 2>&1; $Z reset >/dev/null; }
chk(){ case "$($Z licnow)" in
  OK*) if [ $OK = 0 ]; then OK=1; $Z mode $($Z get mode) >/dev/null; t=$($Z get touch_pct); [ -n "$t" ] && $Z touch $t >/dev/null; fi;;
  *) [ $OK = 1 ] && revert; OK=0;; esac; LT=$(date +%s); }
chk
while true; do
 now=$(date +%s)
 if [ $OK = 1 ]; then [ $((now-LT)) -ge 1800 ] && chk; else [ $((now-LT)) -ge 180 ] && chk; fi
 if [ $OK = 1 ]; then
  fg=$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus | sed 's/.* \([A-Za-z0-9_.]*\)\/.*/\1/')
  if echo ",$($Z get games)," | grep -q ",$fg,"; then
   if [ $IN = 0 ]; then IN=1; $Z mode performance >/dev/null; am start-foreground-service -n $OV --es game "$fg" >/dev/null 2>&1; fi
  elif [ $IN = 1 ]; then IN=0; am stopservice -n $OV >/dev/null 2>&1; $Z mode balanced >/dev/null; fi
  cm=$($Z get clean_min)
  [ "${cm:-0}" -gt 0 ] && [ $((now-LAST)) -ge $((cm*60)) ] && { $Z clean >/dev/null; LAST=$now; }
 fi
 sleep 3
done
