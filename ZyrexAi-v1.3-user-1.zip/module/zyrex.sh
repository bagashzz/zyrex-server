#!/system/bin/sh
D=/data/adb/zyrexai; C=$D/config
mkdir -p $D
[ -f $C ] || printf 'mode=balanced\ngames=\nclean_min=0\ncrosshair=0\ntouch=0\n' > $C
get(){ grep "^$1=" $C | cut -d= -f2-; }
put(){ if grep -q "^$1=" $C; then sed -i "s|^$1=.*|$1=$2|" $C; else echo "$1=$2" >> $C; fi; }
gov(){ for p in /sys/devices/system/cpu/cpu*/cpufreq; do echo $1 > $p/scaling_governor 2>/dev/null; done; }
apply(){
 case $1 in
  powersave) gov powersave; settings put global low_power 1 2>/dev/null
   for p in /sys/devices/system/cpu/cpu*/cpufreq; do m=$(cat $p/cpuinfo_max_freq); echo $((m*60/100)) > $p/scaling_max_freq 2>/dev/null; done;;
  balanced) gov schedutil; settings put global low_power 0 2>/dev/null
   for p in /sys/devices/system/cpu/cpu*/cpufreq; do cat $p/cpuinfo_max_freq > $p/scaling_max_freq 2>/dev/null; done;;
  performance) gov performance; settings put global low_power 0 2>/dev/null
   for p in /sys/devices/system/cpu/cpu*/cpufreq; do cat $p/cpuinfo_max_freq > $p/scaling_max_freq 2>/dev/null; done
   echo 1 > /proc/sys/kernel/sched_boost 2>/dev/null; cmd power set-fixed-performance-mode-enabled true 2>/dev/null;;
 esac
 [ $1 != performance ] && cmd power set-fixed-performance-mode-enabled false 2>/dev/null
}
touchopt(){
 p=$1; n=0
 w(){ [ -w "$2" ] && echo "$1" > "$2" && n=$((n+1)); }
 if [ "$p" -le 0 ]; then lp=400; mp=300; ib=0; gm=0; tb=0
 else lp=$((400-p*2)); mp=$((300-p)); ib=$((p*5)); gm=0; tb=0; [ $p -ge 50 ] && { gm=1; tb=1; }; fi
 settings put secure long_press_timeout $lp; settings put secure multi_press_timeout $mp; n=$((n+2))
 for f in /sys/module/cpu_boost/parameters/input_boost_ms /sys/devices/system/cpu/cpu_boost/input_boost_ms /sys/module/cpu_input_boost/parameters/input_boost_duration; do w $ib $f; done
 for f in /sys/module/msm_performance/parameters/touchboost /sys/kernel/msm_performance/parameters/touchboost; do w $tb $f; done
 for f in /proc/touchpanel/game_switch_enable /sys/class/touch/touch_dev/game_mode /sys/devices/virtual/touch/touch_dev/gamemode /sys/devices/virtual/touch/touch_dev/touch_game_mode; do w $gm $f; done
 for c in /sys/devices/system/cpu/cpu*/cpufreq; do mn=$(cat $c/cpuinfo_min_freq); mx=$(cat $c/cpuinfo_max_freq); v=$mn; [ $p -ge 50 ] && v=$((mn+(mx-mn)*p/200)); w $v $c/scaling_min_freq; done
 echo $n
}
thermal(){
 S="thermal thermald thermal-engine thermal_manager vendor.thermal-hal-2-0 mi_thermald"
 for s in $S; do [ $1 = off ] && stop $s 2>/dev/null || start $s 2>/dev/null; done
 for z in /sys/class/thermal/thermal_zone*/mode; do echo $([ $1 = off ] && echo disabled || echo enabled) > $z 2>/dev/null; done
}
clean(){ pm trim-caches 999G >/dev/null 2>&1; sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; echo ok; }
LIC="app_process -Djava.class.path=/data/adb/modules/zyrexai/system/priv-app/ZyrexAi/ZyrexAi.apk /system/bin com.zyrex.ai.Lic"
case $1 in lic) $LIC verify; exit;; licnow) $LIC check; exit;; serial) $LIC serial; exit;; reset) apply balanced; thermal on; touchopt 0 >/dev/null; exit;; esac
case $1 in mode|gov|thermal|touch|clean|boost) case "$($LIC verify)" in OK*) ;; *) echo DENY; exit 3;; esac;; esac
case $1 in
 mode) put mode $2; apply $2;;
 get) get $2;;
 set) put $2 "$3";;
 gov) gov $2;;
 govs) cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors;;
 curgov) cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor;;
 thermal) thermal $2; put thermal $2;;
 touch) p=${2:-0}; put touch_pct $p; touchopt $p;;
 clean) clean;;
 game) g=$(get games); if [ "$2" = add ]; then echo ",$g," | grep -q ",$3," || put games "${g:+$g,}$3"; else put games "$(echo ,$g, | sed "s|,$3,|,|;s|^,||;s|,$||")"; fi;;
 boost) $0 game add $2; $0 mode performance; am start-foreground-service -n com.zyrex.ai/.OverlayService --es game "$2" >/dev/null 2>&1; monkey -p $2 -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1;;
 apps) pm list packages -3 | cut -d: -f2 | sort;;
esac
