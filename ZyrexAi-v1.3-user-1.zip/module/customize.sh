ui_print "- ZyrexAi Game Booster v1.3 (berlisensi)"
S=$(getprop ro.serialno); [ -z "$S" -o "$S" = unknown ] && S=$(getprop ro.boot.serialno)
ui_print "- Serial perangkat: $S"
ui_print "- Kirim serial ini ke developer untuk aktivasi"
mkdir -p /data/adb/zyrexai
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system 0 0 0755 0644 u:object_r:system_file:s0
set_perm $MODPATH/zyrex.sh 0 0 0755
set_perm $MODPATH/gamed.sh 0 0 0755
