#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 5; done
appops set com.zyrex.ai SYSTEM_ALERT_WINDOW allow 2>/dev/null
nohup /data/adb/modules/zyrexai/gamed.sh >/dev/null 2>&1 &
