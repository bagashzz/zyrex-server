package com.zyrex.admin
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView

class MainActivity : Activity() {
  @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    window.statusBarColor = 0xFF05040D.toInt(); window.navigationBarColor = 0xFF05040D.toInt()
    val wv = WebView(this); setContentView(wv)
    wv.setBackgroundColor(0xFF05040D.toInt())
    wv.settings.javaScriptEnabled = true; wv.settings.domStorageEnabled = true
    wv.webChromeClient = WebChromeClient()
    wv.addJavascriptInterface(object { @JavascriptInterface fun copy(t: String) {
      (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("s", t)) } }, "Admin")
    wv.loadUrl("file:///android_asset/admin.html")
  }
}
