package com.zyrex.ai
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
  private val views = ArrayList<View>()
  private lateinit var wm: WindowManager
  override fun onBind(i: Intent?): IBinder? = null
  override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("zy", "ZyrexAi", NotificationManager.IMPORTANCE_MIN))
    val n = Notification.Builder(this, "zy").setContentTitle("ZyrexAi Booster aktif").setSmallIcon(R.drawable.ic).build()
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    Thread {
      val cfg = try { Runtime.getRuntime().exec(arrayOf("su", "-c", "cat /data/adb/zyrexai/config")).inputStream.bufferedReader().readText() } catch (e: Exception) { "" }
      val kv = cfg.lines().filter { it.contains("=") }.associate { it.substringBefore("=") to it.substringAfter("=") }
      Handler(Looper.getMainLooper()).post { show(kv["mode"] ?: "performance", kv["crosshair"] == "1") }
    }.start()
    return START_NOT_STICKY
  }
  private fun lp(g: Int, y: Int) = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
    PixelFormat.TRANSLUCENT).also { it.gravity = g; it.y = y }
  private fun show(mode: String, cross: Boolean) {
    clear()
    val d = resources.displayMetrics.density
    val pill = TextView(this).apply { text = "⚡ ZyrexAi • $mode"; setTextColor(Color.WHITE); textSize = 11f
      setPadding((12 * d).toInt(), (5 * d).toInt(), (12 * d).toInt(), (5 * d).toInt())
      background = android.graphics.drawable.GradientDrawable().apply { setColor(0xCC0B0920.toInt()); cornerRadius = 40 * d; setStroke(d.toInt(), 0xFF00E5FF.toInt()) } }
    wm.addView(pill, lp(Gravity.TOP or Gravity.CENTER_HORIZONTAL, (8 * d).toInt())); views.add(pill)
    if (cross) {
      val cv = object : View(this) {
        override fun onDraw(c: Canvas) {
          val x = width / 2f; val y = height / 2f; val g = 6 * d; val l = 16 * d
          for ((col, w) in listOf(Color.BLACK to 4 * d, 0xFF00E5FF.toInt() to 2 * d)) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col; strokeWidth = w }
            c.drawLine(x - g - l, y, x - g, y, p); c.drawLine(x + g, y, x + g + l, y, p)
            c.drawLine(x, y - g - l, x, y - g, p); c.drawLine(x, y + g, x, y + g + l, p)
            c.drawCircle(x, y, if (col == Color.BLACK) 2.5f * d else 1.2f * d, p.apply { style = Paint.Style.FILL })
          }
        }
      }
      cv.minimumWidth = (80 * d).toInt(); cv.minimumHeight = (80 * d).toInt()
      wm.addView(cv, lp(Gravity.CENTER, 0)); views.add(cv)
    }
  }
  private fun clear() { views.forEach { try { wm.removeView(it) } catch (e: Exception) {} }; views.clear() }
  override fun onDestroy() { clear(); super.onDestroy() }
}
