package com.zyrex.ai
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread

class MainActivity : Activity() {
  lateinit var wv: WebView
  @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    window.statusBarColor = 0xFF05040D.toInt(); window.navigationBarColor = 0xFF05040D.toInt()
    if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    wv = WebView(this); setContentView(wv)
    wv.setBackgroundColor(0xFF05040D.toInt())
    wv.settings.javaScriptEnabled = true
    wv.settings.mediaPlaybackRequiresUserGesture = false
    wv.addJavascriptInterface(Bridge(), "ksu")
    wv.webViewClient = object : WebViewClient() {
      override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
        if (r.url.scheme == "ksu" && r.url.host == "icon") {
          return try {
            val d = packageManager.getApplicationIcon(r.url.path!!.trimStart('/'))
            val bm = Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 144, 144); d.draw(Canvas(bm))
            val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, o)
            WebResourceResponse("image/png", null, ByteArrayInputStream(o.toByteArray()))
          } catch (e: Exception) { null }
        }
        return null
      }
    }
    wv.loadUrl("file:///android_asset/index.html")
  }
  inner class Bridge {
    @JavascriptInterface fun exec(cmd: String, opts: String, cb: String) { thread {
      val out = try { val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)); val s = p.inputStream.bufferedReader().readText(); p.waitFor(); s } catch (e: Exception) { "" }
      runOnUiThread { wv.evaluateJavascript("window['$cb'](0,${JSONObject.quote(out)},'')", null) } } }
    @JavascriptInterface fun getPackagesInfo(j: String): String {
      val a = JSONArray(j); val r = JSONArray()
      for (i in 0 until a.length()) { val p = a.getString(i)
        try { r.put(JSONObject().put("packageName", p).put("appLabel", packageManager.getApplicationLabel(packageManager.getApplicationInfo(p, 0)).toString())) } catch (e: Exception) {} }
      return r.toString()
    }
  }
}
