package com.zyrex.ai;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/** Dijalankan root via app_process: Lic serial|verify|check  -> "OK|exp|SERIAL" / "DENY|alasan|SERIAL" */
public class Lic {
  static final String F = "/data/adb/zyrexai/license";
  public static void main(String[] a) {
    String c = a.length > 0 ? a[0] : "verify", s = serial();
    if (c.equals("serial")) { System.out.println(s); return; }
    System.out.println((c.equals("check") ? check(s) : verify(s)) + "|" + s);
  }
  static String serial() {
    for (String k : new String[]{"ro.serialno", "ro.boot.serialno", "ro.serial", "sys.serialnumber"}) {
      try {
        Process p = Runtime.getRuntime().exec(new String[]{"getprop", k});
        String v = new BufferedReader(new InputStreamReader(p.getInputStream())).readLine();
        if (v != null) { v = v.trim().toUpperCase(); if (!v.isEmpty() && !v.equals("UNKNOWN")) return v; }
      } catch (Exception e) {}
    }
    return "UNKNOWN";
  }
  static boolean sigOk(String s, String n, long iat, long exp, long g, String sig) {
    try {
      PublicKey k = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(BuildConfig.ZY_PUBKEY.trim())));
      Signature v = Signature.getInstance("SHA256withECDSA"); v.initVerify(k);
      v.update((s + "|" + n + "|" + iat + "|" + exp + "|" + g).getBytes("UTF-8"));
      return v.verify(Base64.getDecoder().decode(sig));
    } catch (Exception e) { return false; }
  }
  static String verify(String s) {
    try {
      File f = new File(F); if (!f.exists()) return "DENY|none";
      JSONObject j = new JSONObject(new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8"));
      if (!sigOk(j.getString("serial"), j.getString("nonce"), j.getLong("iat"), j.getLong("exp"), j.getLong("grace"), j.getString("sig"))) return "DENY|bad_sig";
      if (!j.getString("serial").equals(s)) return "DENY|serial";
      long n = System.currentTimeMillis() / 1000;
      if (n < j.getLong("iat") - 300) return "DENY|clock";
      if (n > j.getLong("exp")) return "DENY|expired";
      if (n > j.getLong("iat") + j.getLong("grace")) return "DENY|offline_grace";
      return "OK|" + j.getLong("exp");
    } catch (Exception e) { return "DENY|none"; }
  }
  static String check(String s) {
    try {
      String nonce = Long.toHexString(new SecureRandom().nextLong()) + Long.toHexString(System.nanoTime());
      HttpURLConnection h = (HttpURLConnection) new URL(BuildConfig.ZY_SERVER.replaceAll("/+$", "") + "/api/check").openConnection();
      h.setConnectTimeout(8000); h.setReadTimeout(8000); h.setRequestMethod("POST"); h.setDoOutput(true);
      h.setRequestProperty("Content-Type", "application/json");
      h.getOutputStream().write(new JSONObject().put("serial", s).put("nonce", nonce).toString().getBytes("UTF-8"));
      if (h.getResponseCode() != 200) return verify(s);
      StringBuilder sb = new StringBuilder(); BufferedReader br = new BufferedReader(new InputStreamReader(h.getInputStream()));
      for (String l; (l = br.readLine()) != null; ) sb.append(l);
      JSONObject j = new JSONObject(sb.toString());
      if (!j.optBoolean("ok")) { new File(F).delete(); return "DENY|" + j.optString("reason", "unknown"); }
      if (!j.getString("serial").equals(s) || !j.getString("nonce").equals(nonce)
          || !sigOk(s, nonce, j.getLong("iat"), j.getLong("exp"), j.getLong("grace"), j.getString("sig"))) return verify(s);
      new File(F).getParentFile().mkdirs();
      FileWriter w = new FileWriter(F); w.write(j.toString()); w.close();
      return verify(s);
    } catch (Exception e) { return verify(s); }
  }
}
